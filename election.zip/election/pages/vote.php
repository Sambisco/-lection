<?php 
session_start();
if(isset($_SESSION['profil'])){
include('../include/css.php');
include('../include/navbar.php');
include('../include/sidebar.php');
include('../include/database.php');
?>
		 	<?php 
			 $user =$_SESSION['id_centre'];
    $query="select `id_bureau`, `nom_bureau` from bureau INNER JOIN centre ON centre.id_centre=bureau.id_centre WHERE centre.id_centre='$user' ORDER BY id_bureau DESC";
    $bureau="";
    $statement=$db->prepare($query);
	$statement->execute();
$result=$statement->fetchAll();
$total_row=$statement->rowCount();
    if($total_row>0){
      foreach($result as $row){
        $bureau.="<option value='{$row["id_bureau"]}'>{$row["nom_bureau"]}</option>";
      }
    }
  ?>
  <?php 
    $query="SELECT * FROM `partie` ORDER BY id_partie DESC";
    $partie="";
    $statement=$db->prepare($query);
	$statement->execute();
$result=$statement->fetchAll();
$total_row=$statement->rowCount();
    if($total_row>0){
      foreach($result as $row){
        $partie.="<option value='{$row["id_partie"]}'>{$row["partie"]}</option>";
      }
    }
  ?>
<div class="dashboard-wrapper">
            <div class="container-fluid  dashboard-content">
                <!-- ============================================================== -->
                <!-- pageheader -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="page-header">
                            <h2 class="pageheader-title">Votes</h2>
                            <p class="pageheader-text">Proin placerat ante duiullam scelerisque a velit ac porta, fusce sit amet vestibulum mi. Morbi lobortis pulvinar quam.</p>
                            <div class="page-breadcrumb">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Tableau de bord</a></li>
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Tables</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Votes</li>
                                    </ol>
                                </nav>
								<?php 
	if(isset($_SESSION['message_add'])){?>
	<div class="alert alert-success" <?=$_SESSION['msg_type_add'] ?>>
	<?php 
	echo $_SESSION['message_add'];
	unset($_SESSION['message_add']);
	?>
	</div>
	<?php }else if(isset($_SESSION['message_update'])){?>
	<div class="alert alert-warning" <?=$_SESSION['msg_type_update'] ?>>
	<?php 
	echo $_SESSION['message_update'];
	unset($_SESSION['message_update']);
	?>
	</div>
	<?php }else if(isset($_SESSION['message_delete'])){?>
	<div class="alert alert-danger" <?=$_SESSION['msg_type_delete'] ?>>
	<?php 
	echo $_SESSION['message_delete'];
	unset($_SESSION['message_delete']);
	?>
	</div>
	<?php }?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- end pageheader -->
                <!-- ============================================================== -->
                <div class="row">
                    <!-- ============================================================== -->
                    <!-- basic table  -->
                    <!-- ============================================================== -->
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="card">
                            <div class="card-header">
                     <button type="button" class="btn btn-dark" data-toggle="modal" data-target="#exampleModal">Ajouter</button>
                            </div>

                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered first" id="bootstrap-data-table-export" data-order='[[0,"desc"]]'>
                                        <thead>
                                            <tr>
                                                <th>ID</th>
												<th style="display:none">ID_b</th>
                                                <th>Bureau de vote</th>
												<th style="display:none">ID_c</th>
												<th>Partie poliique</th>
                                                <th>Nombre de vote</th>
												<th>Centre de vote</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                           
                                              <?php 
											  if($_SESSION['profil']=='Administrateur'){
											  $user =$_SESSION['id_centre'];
                                    $query="SELECT * FROM vote INNER JOIN partie ON partie.id_partie=vote.id_partie INNER JOIN bureau ON bureau.id_bureau=vote.id_bureau INNER JOIN centre ON centre.id_centre=bureau.id_centre
 ";
                                    $statement=$db->prepare($query);
                                    $statement->execute();
                                    $result=$statement->fetchAll();
                                    $total_row=$statement->rowCount();
									}else if($_SESSION['profil']=='Utilisateur'){
									$user =$_SESSION['id_centre'];
 $query="SELECT * FROM vote INNER JOIN partie ON partie.id_partie=vote.id_partie INNER JOIN bureau ON bureau.id_bureau=vote.id_bureau INNER JOIN centre ON centre.id_centre=bureau.id_centre
 WHERE centre.id_centre='$user'
 ";
                                    $statement=$db->prepare($query);
                                    $statement->execute();
                                    $result=$statement->fetchAll();
                                    $total_row=$statement->rowCount();
									}
									if ($total_row>0){
		                             foreach($result as $row){
									?>
                                     <tr>
                                     <td ><?php echo $row["id_vote"];?></td>
                                     <td style="display:none"><?php echo $row["id_bureau"];?></td>
									 <td ><?php echo $row["nom_bureau"];?></td>
									  <td style="display:none"><?php echo $row["id_partie"];?></td>
									  <td><?php echo $row["partie"];?></td>
									  <td><?php echo $row["nb_vote"];?></td>
									  <td><?php echo $row["nom_centre"];?></td>
                                     <td><button class="btn btn-outline-dark btn-sm editbtn"><i class="fa fa-edit"></i></button>
									  <button class="btn btn-outline-dark btn-sm deletebtn"> <i class="fa fa-trash"></i></button>
									</td>
                                        </tr>
										       <?php
                                                }
                                                }else{
                                                echo' <tr>
                                                <td colspan="4" align="center"> Aucune donnée enregistré</td>
                                                </tr>';
                                                }
                                               ?>
                                        </tbody>
                                       
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end basic table  -->
                    <!-- ============================================================== -->
                </div>
               
             </div>
			 <!-- ============================================================== -->
	
			  <!------FORMULAIRE AJOUTER------->
 <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Inséré une vote</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
		<form action="../controller/contro_vote.php" method="post" enctype="multipart/form-data">
      </div>
      <div class="modal-body">
     
<div class="form-group">
<label>Bureau de vote</label>
<select name="id_bureau" class="form-control form-control-sm" required="" id="id_bureau" style="width:100%">
  <option value="">Selectionnez</option>
  <?php echo $bureau;?>
</select>
</div>
<div class="form-group">
<label>Partie politique</label>
<select name="id_partie" class="form-control form-control-sm" required="" id="id_partie" style="width:100%">
  <option value="">Selectionnez</option>
  <?php echo $partie;?>
</select>
</div>
<div class="form-group">
<label>Nombre de votes</label>
<input name="nb_vote" type="text" id="nb" class="form-control form-control-sm" placeholder="Nombre de votes" required>
</div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-dark" name="insertdata">Enregister</button>
		 <button type="button" class="btn btn-outline-danger" data-dismiss="modal">Annuler</button>
      </div>
	  </form>
    </div>
  </div>
</div>
<!------FIN FORMULAIRE AJOUTER------->
<!------FORMULAIRE MODIFIER------->
<div class="modal fade" id="editmodal" tabindex="-1" role="dialog" area-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="exampleModalLabel"> Modifié une vote</h5>
<button class="close" data-dismiss="modal" aria-label="aria-label""close"><span aria-hidden="true"></span>&times;</button>
</div>
<form action="../controller/contro_vote.php" method="post" enctype="multipart/form-data">
<div class="modal-body">
<input name="id_vote" type="hidden" id="edit_id_vote">
<div class="form-group">
<label>Bureau de vote</label>
<select name="id_bureau" id="edit_nom" class="form-control form-control-sm" required="" style="width:100%">
  <option value="">Selectionnez</option>
   <?php echo $bureau;?>
</select>
</div>
<div class="form-group">
<label>Partie politique</label>
<select name="id_partie" class="form-control form-control-sm" required="" id="edit_partie" style="width:100%">
  <option value="">Selectionnez</option>
  <?php echo $partie;?>
</select>
</div>
<div class="form-group">
<label>Nombre de votes</label>
<input name="nb_vote" type="text" id="nb_v" class="form-control form-control-sm" placeholder="Nombre de votes" required>
</div>

</div>

<div class="modal-footer">
<button type="submit" name="updatetdata" class="btn btn-dark">Modifier</button>
<button type="button" class="btn btn-outline-danger" data-dismiss="modal">Annuler</button>


</div>
</form>
</div>
</div>
</div>
<!------FIN FORMULAIRE MODIFIER------->
<!------FORMULAIRE SUPPRIMER------->
<div class="modal fade" id="deletemodal" tabindex="-1" role="dialog" area-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="exampleModalLabel"> Supprimer une vote</h5>
<button class="close" data-dismiss="modal" aria-label="aria-label""close"><span aria-hidden="true"></span>&times;</button>
</div>
<form action="../controller/contro_vote.php" method="post" enctype="multipart/form-data">
<div class="modal-body">
<input name="delete_id" type="hidden" id="delete_id" />

<h4>Voulez-vous vraiment supprimer une vote</h4>

</div>

<div class="modal-footer">
<button type="submit" name="deletedata" class="btn btn-dark">Supprimer</button>
<button type="button" class="btn btn-outline-danger" data-dismiss="modal">Annuler</button>


</div>
</form>
</div>
</div>
</div>
<!------FIN FORMULAIRE SUPPRIMER------->
<?php 
include('../include/script.php');
include('../include/footer.php');
?>
<script>
$(document).ready(function() {
  $("#id_bureau").select2({
    dropdownParent: $("#exampleModal")
  });
});
$(document).ready(function() {
  $("#id_partie").select2({
    dropdownParent: $("#exampleModal")
  });
});
$(document).ready(function() {
  $("#edit_nom").select2({
    dropdownParent: $("#editmodal")
  });
});
$(document).ready(function() {
  $("#edit_partie").select2({
    dropdownParent: $("#editmodal")
  });
});
$(document).ready(function () {
    $('#bootstrap-data-table-export').DataTable({
            "language": {
                "sEmptyTable":     "Aucune donnée disponible dans le tableau",
                "sInfo":           "Affichage de l'élément _START_ à _END_ sur _TOTAL_ éléments",
                "sInfoEmpty":      "Affichage de l'élément 0 à 0 sur 0 élément",
                "sInfoFiltered":   "(filtré à partir de _MAX_ éléments au total)",
                "sInfoPostFix":    "",
                "sInfoThousands":  ",",
                "sLengthMenu":     "Afficher _MENU_ éléments",
                "sLoadingRecords": "Chargement...",
                "sProcessing":     "Traitement...",
                "sSearch":         "Rechercher :",
                "sZeroRecords":    "Aucun élément correspondant trouvé",
                "oPaginate": {
                    "sFirst":    "Premier",
                    "sLast":     "Dernier",
                    "sNext":     "Suivant",
                    "sPrevious": "Précédent"
                },
                "oAria": {
                    "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
                    "sSortDescending": ": activer pour trier la colonne par ordre décroissant"
                },
                "select": {
                    "rows": {
                        "_": "%d lignes sélectionnées",
                        "0": "Aucune ligne sélectionnée",
                        "1": "1 ligne sélectionnée"
                    }
                }
            }
    });
});
$(document).ready(function(){
$(".editbtn").click(function(){
$("#editmodal").modal('show');
$str=$(this).closest('tr');
var data=$str.children("td").map(function(){
return $(this).text();
}).get();
console.log(data);
$("#edit_id_vote").val(data[0]);
$("#edit_nom").val(data[1]);
$("#edit_partie").val(data[3]);
$("#nb_v").val(data[5]);


});

});

$(document).ready(function(){
$(".deletebtn").click(function(){
$("#deletemodal").modal('show');
$str=$(this).closest('tr');
var data=$str.children("td").map(function(){
return $(this).text();
}).get();
console.log(data);
$("#delete_id").val(data[0]);


});

});
</script>
<?php 
}else if(isset($_SESSION['profil'])==''){
header("Location:../index.php");
}?>