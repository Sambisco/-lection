<?php 
session_start();
if(isset($_SESSION['profil'])){
include('../include/css.php');
include('../include/navbar.php');
include('../include/sidebar.php');
include('../include/database.php');
?>
 <div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content ">
                    <!-- ============================================================== -->
                    <!-- pageheader  -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h2 class="pageheader-title">Tableau de bord Election locale </h2>
                                <p class="pageheader-text">Nulla euismod urna eros, sit amet scelerisque torton lectus vel mauris facilisis faucibus at enim quis massa lobortis rutrum.</p>
                                <div class="page-breadcrumb">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Tableau de bord</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Election locale</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end pageheader  -->
                    <!-- ============================================================== -->
                    <div class="ecommerce-widget">

                       
                        <div class="row">
                            <!-- ============================================================== -->
                            <!-- bureau de vote  -->
                            <!-- ============================================================== -->
							<?php if($_SESSION['profil']=='Administrateur'){
						?>
                            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                                <div class="card border-3 border-top border-top-primary">
                                    <div class="card-body">
                                        <h5 class="text-muted">Bureau de votes</h5>
										<?php 
										$query="SELECT count(*) as nb FROM bureau";
                                    $statement=$db->prepare($query);
                                    $statement->execute();
                                    $result=$statement->fetch();
									if($result){
										?>
                                        <div class="metric-value d-inline-block">
                                            <h1 class="mb-1"><?php echo $result['nb'];?></h1>
										<?php }?>
                                        </div>
                                        <div class="metric-label d-inline-block float-right text-success font-weight-bold">
                                            <span class="icon-circle-small icon-box-xs text-success bg-success-light"><i class="fa fa-fw fa-arrow-up"></i></span><span class="ml-1"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
							<?php
}else if($_SESSION['profil']=='Utilisateur'){
?>
<div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                                <div class="card border-3 border-top border-top-primary">
                                    <div class="card-body">
                                        <h5 class="text-muted">Bureau de votes</h5>
										<?php 
										$user =$_SESSION['id_centre'];
										$query="SELECT count(*) as nb FROM bureau INNER JOIN centre ON centre.id_centre=bureau.id_centre WHERE centre.id_centre='$user'";
                                    $statement=$db->prepare($query);
                                    $statement->execute();
                                    $result=$statement->fetch();
									if($result){
										?>
                                        <div class="metric-value d-inline-block">
                                            <h1 class="mb-1"><?php echo $result['nb'];?></h1>
										<?php }?>
                                        </div>
                                        <div class="metric-label d-inline-block float-right text-success font-weight-bold">
                                            <span class="icon-circle-small icon-box-xs text-success bg-success-light"><i class="fa fa-fw fa-arrow-up"></i></span><span class="ml-1"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
<?php
}?>
     
                            <!-- ============================================================== -->
                            <!-- fin bureau de vote  -->
                            <!-- ============================================================== -->
                            <!-- ============================================================== -->
                            <!-- partie politique  -->
                            <!-- ============================================================== -->
                            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                                <div class="card border-3 border-top border-top-primary">
                                    <div class="card-body">
                                        <h5 class="text-muted">Parties politiques</h5>
										<?php 
										$query="SELECT count(*) as nb FROM partie";
                                    $statement=$db->prepare($query);
                                    $statement->execute();
                                    $result=$statement->fetch();
									if($result){
										?>
                                        <div class="metric-value d-inline-block">
                                            <h1 class="mb-1"><?php echo $result['nb'];?></h1>
                                        </div>
										<?php }?>
                                        <div class="metric-label d-inline-block float-right text-success font-weight-bold">
                                            <span class="icon-circle-small icon-box-xs text-success bg-success-light"><i class="fa fa-fw fa-arrow-up"></i></span><span class="ml-1"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- ============================================================== -->
                            <!-- fin partie politique  -->
                            <!-- ============================================================== -->
                            <!-- ============================================================== -->
                            <!-- Nombre d'inscrits  -->
                            <!-- ============================================================== -->
							<?php if($_SESSION['profil']=='Administrateur'){
						?>
                            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                                <div class="card border-3 border-top border-top-primary">
                                    <div class="card-body">
                                        <h5 class="text-muted">Nombre d'inscrits</h5>
										<?php 
										$query="SELECT count(*) as nb FROM inscrit";
                                    $statement=$db->prepare($query);
                                    $statement->execute();
                                    $result=$statement->fetch();
									if($result){
										?>
                                        <div class="metric-value d-inline-block">
                                            <h1 class="mb-1"><?php echo $result['nb']; ?></h1>
											<?php }?>
                                        </div>
                                        <div class="metric-label d-inline-block float-right text-success font-weight-bold">
                                            <span class="icon-circle-small icon-box-xs text-success bg-success-light"><i class="fa fa-fw fa-arrow-up"></i></span><span class="ml-1"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
							<?php
}else if($_SESSION['profil']=='Utilisateur'){
?>
<div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                                <div class="card border-3 border-top border-top-primary">
                                    <div class="card-body">
                                        <h5 class="text-muted">Nombre d'inscrits</h5>
										<?php 
										$user =$_SESSION['id_centre'];
										$query="SELECT count(*) as nb FROM inscrit INNER JOIN bureau ON bureau.id_bureau=inscrit.id_bureau INNER JOIN centre ON centre.id_centre=bureau.id_centre WHERE centre.id_centre='$user'";
                                    $statement=$db->prepare($query);
                                    $statement->execute();
                                    $result=$statement->fetch();
									if($result){
										?>
                                        <div class="metric-value d-inline-block">
                                            <h1 class="mb-1"><?php echo $result['nb'];?></h1>
											<?php }?>
                                        </div>
                                        <div class="metric-label d-inline-block float-right text-success font-weight-bold">
                                            <span class="icon-circle-small icon-box-xs text-success bg-success-light"><i class="fa fa-fw fa-arrow-up"></i></span><span class="ml-1"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
<?php }?>

                            <!-- ============================================================== -->
                            <!-- fin Nombre d'inscrits
  -->
                            <!-- ============================================================== -->
                            <!-- ============================================================== -->
                            <!-- nombre de vote  -->
                            <!-- ============================================================== -->
                           <?php if($_SESSION['profil']=='Administrateur'){
						?>
                            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                                <div class="card border-3 border-top border-top-primary">
                                    <div class="card-body">
                                        <h5 class="text-muted">Nombre de votes</h5>
										<?php 
										$query="SELECT count(*) as nb FROM vote";
                                    $statement=$db->prepare($query);
                                    $statement->execute();
                                    $result=$statement->fetch();
									if($result){
										?>
                                        <div class="metric-value d-inline-block">
                                            <h1 class="mb-1"><?php echo $result['nb']; ?></h1>
											<?php }?>
                                        </div>
                                        <div class="metric-label d-inline-block float-right text-success font-weight-bold">
                                            <span class="icon-circle-small icon-box-xs text-success bg-success-light"><i class="fa fa-fw fa-arrow-up"></i></span><span class="ml-1"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
							<?php
}else if($_SESSION['profil']=='Utilisateur'){
?>
<div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                                <div class="card border-3 border-top border-top-primary">
                                    <div class="card-body">
                                        <h5 class="text-muted">Nombre de votes</h5>
										<?php 
										$user =$_SESSION['id_centre'];
										$query="SELECT count(*) as nb FROM vote INNER JOIN bureau ON bureau.id_bureau=vote.id_bureau INNER JOIN centre ON centre.id_centre=bureau.id_centre WHERE centre.id_centre='$user'";
                                    $statement=$db->prepare($query);
                                    $statement->execute();
                                    $result=$statement->fetch();
									if($result){
										?>
                                        <div class="metric-value d-inline-block">
                                            <h1 class="mb-1"><?php echo $result['nb'];?></h1>
											<?php }?>
                                        </div>
                                        <div class="metric-label d-inline-block float-right text-success font-weight-bold">
                                            <span class="icon-circle-small icon-box-xs text-success bg-success-light"><i class="fa fa-fw fa-arrow-up"></i></span><span class="ml-1"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
<?php }?>

                            <!-- ============================================================== -->
                            <!-- fin nombre de vote  -->
                            <!-- ============================================================== -->
                        </div>
                        <div class="row">
                            <!-- ============================================================== -->
                            <!-- total revenue  -->
                            <!-- ============================================================== -->
  
                            
                            <!-- ============================================================== -->
                            <!-- ============================================================== -->
                            <!-- category revenue  -->
                            <!-- ============================================================== -->
                           <div class="container-fluid">
			<div class="row">
				
				<div class="col-md-6">
					<div class="card mt-4">
						<div class="card-header">Pourcentage centre de vote</div>
						<div class="card-body">
							<div class="chart-container pie-chart">
								<canvas id="bar_chart_centre" ></canvas>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="card mt-4 mb-4">
						<div class="card-header">Pourcentage partie</div>
						<div class="card-body">
							<div class="chart-container pie-chart">
								<canvas id="bar_chart_partie"></canvas>
							</div>
						</div>
					</div>
				</div>
			</div>
			
				
				
			</div>
                            <!-- ============================================================== -->
                            <!-- end category revenue  -->
				
				<div class="col-md-6">
					<div class="card mt-4">
						<div class="card-header">Total des votes par centre</div>
						<div class="card-body">
							<div class="chart-container pie-chart">
								<canvas id="bar_chart_centre_somme" ></canvas>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="card mt-4 mb-4">
						<div class="card-header">Total des votes par partie</div>
						<div class="card-body">
							<div class="chart-container pie-chart">
								<canvas id="bar_chart_partie_somme"></canvas>
							</div>
						</div>
					</div>
				
			
			</div>
                            <!-- ============================================================== -->

                            
                        </div>
                       
                    </div>
                </div>
            </div>
			<?php 
include('../include/script.php');
include('../include/footer.php');
?>
<script>
$(document).ready(function(){

	chart_centre_pourcentage();

	function chart_centre_pourcentage()
	{
		$.ajax({
			url:"../controller/chart_centre.php",
			method:"POST",
			data:{action:'fetch'},
			dataType:"JSON",
			success:function(data)
			{
				var language = [];
				var total = [];
				var color = [];

				for(var count = 0; count < data.length; count++)
				{
					language.push(data[count].language);
					total.push(data[count].total);
					color.push(data[count].color);
				}

				var chart_data = {
					labels:language,
					datasets:[
						{
							label:'Pourcentage',
							backgroundColor:color,
							color:'#fff',
							data:total
						}
					]
				};

				var options = {
					responsive:true,
					scales:{
						yAxes:[{
							ticks:{
								min:0
							}
						}]
					}
				};

				var group_chart3 = $('#bar_chart_centre');

				var graph3 = new Chart(group_chart3, {
					type:'bar',
					data:chart_data,
					options:options
				});
			}
		})
	}

chart_partie_pourcentage();

	function chart_partie_pourcentage()
	{
		$.ajax({
			url:"../controller/chart_partie.php",
			method:"POST",
			data:{action:'fetch'},
			dataType:"JSON",
			success:function(data)
			{
				var language = [];
				var total = [];
				var color = [];

				for(var count = 0; count < data.length; count++)
				{
					language.push(data[count].language);
					total.push(data[count].total);
					color.push(data[count].color);
				}

				var chart_data = {
					labels:language,
					datasets:[
						{
							label:'Pourcentage',
							backgroundColor:color,
							color:'#fff',
							data:total
						}
					]
				};

				var options = {
					responsive:true,
					scales:{
						yAxes:[{
							ticks:{
								min:0
							}
						}]
					}
				};

				var group_chart3 = $('#bar_chart_partie');

				var graph3 = new Chart(group_chart3, {
					type:'bar',
					data:chart_data,
					options:options
				});
			}
		})
	}
	chart_centre_somme();

	function chart_centre_somme()
	{
		$.ajax({
			url:"../controller/chart_centre_somme.php",
			method:"POST",
			data:{action:'fetch'},
			dataType:"JSON",
			success:function(data)
			{
				var language = [];
				var total = [];
				var color = [];

				for(var count = 0; count < data.length; count++)
				{
					language.push(data[count].language);
					total.push(data[count].total);
					color.push(data[count].color);
				}

				var chart_data = {
					labels:language,
					datasets:[
						{
							label:'Total',
							backgroundColor:color,
							color:'#fff',
							data:total
						}
					]
				};

				var options = {
					responsive:true,
					scales:{
						yAxes:[{
							ticks:{
								min:0
							}
						}]
					}
				};

				var group_chart3 = $('#bar_chart_centre_somme');

				var graph3 = new Chart(group_chart3, {
					type:'line',
					data:chart_data,
					options:options
				});
			}
		})
	}
	chart_partie_somme();

	function chart_partie_somme()
	{
		$.ajax({
			url:"../controller/chart_partie _somme.php",
			method:"POST",
			data:{action:'fetch'},
			dataType:"JSON",
			success:function(data)
			{
				var language = [];
				var total = [];
				var color = [];

				for(var count = 0; count < data.length; count++)
				{
					language.push(data[count].language);
					total.push(data[count].total);
					color.push(data[count].color);
				}

				var chart_data = {
					labels:language,
					datasets:[
						{
							label:'Total',
							backgroundColor:color,
							color:'#fff',
							data:total
						}
					]
				};

				var options = {
					responsive:true,
					scales:{
						yAxes:[{
							ticks:{
								min:0
							}
						}]
					}
				};

				var group_chart3 = $('#bar_chart_partie_somme');

				var graph3 = new Chart(group_chart3, {
					type:'line',
					data:chart_data,
					options:options
				});
			}
		})
	}
});
</script>
<?php 
}else if(isset($_SESSION['profil'])==''){
header("Location:../index.php");
}?>