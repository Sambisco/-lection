<?php 
session_start();
if(isset($_SESSION['profil'])){
include('../include/css.php');
include('../include/navbar.php');
include('../include/sidebar.php');
include('../include/database.php');
?>
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- wrapper  -->
        <!-- ============================================================== -->
        <div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content ">
                    <!-- ============================================================== -->
                    <!-- pageheader  -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h2 class="pageheader-title">Tableau Pourcentage et total </h2>
                                <p class="pageheader-text">Nulla euismod urna eros, sit amet scelerisque torton lectus vel mauris facilisis faucibus at enim quis massa lobortis rutrum.</p>
                                <div class="page-breadcrumb">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Tableau de bord</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Tableau Pourcentage et total</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end pageheader  -->
                    <!-- ============================================================== -->
                    <div class="ecommerce-widget">

                        <div class="row">
                            <!-- ============================================================== -->
                      
                            <!-- ============================================================== -->

                                          <!-- pourcentage  -->
                            <!-- ============================================================== -->
                            <div class="col-xl-6 col-lg-12 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <h5 class="card-header">
									<div class="col-sm-6">Pourcentage centre de vote
</div>
									<div class="col-sm-2">
			<button class="btn btn-primary btn-sm font-weight-bold " data-toggle="modal" name="" id="btn_pourc_centre"><i class="fa   fa-file-excel-o"></i> Exporter</button>

</div>
									</h5>
                                    <div class="card-body p-0">
                                        <div class="table-responsive">
                                           <table class="table table-striped table-bordered table-sm export_pourc_centre" id="bootstrap-data-table-pourc_centre" data-order='[[0,"desc"]]'>
					<thead>
						<tr>
							<th>#</th>
							<th>Centre de vote</th>
							<th>Pourcentage</th>
						</tr>
					</thead>
					<tbody>
					<?php 
					$query = "
SELECT id_vote,centre.nom_centre as nom_centre, format((SUM(nb_vote) * COUNT(id_vote)/100),2) AS Total FROM vote INNER JOIN bureau ON bureau.id_bureau=vote.id_bureau INNER JOIN centre ON centre.id_centre=bureau.id_centre GROUP BY centre.id_centre
		
	";
$statement = $db->prepare($query);
$statement->execute();
$result = $statement->fetchAll();
$total_row = $statement->rowCount();
if($total_row > 0)
{
	foreach($result as $row)
	{
?>
<tr>
<td><?php echo $row["id_vote"]; ?></td>
<td><?php echo $row["nom_centre"] ?></td>
<td><?php echo $row["Total"] ?></td>
</tr>
<?php 
}
}
?>
</tbody>
				</table>
                                        </div>
                                    </div>
                                </div>
                            </div>
							 <div class="col-xl-6 col-lg-12 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <h5 class="card-header">
									<div class="col-sm-6">Pourcentage Partie politique
</div>
									<div class="col-sm-2">
			<button class="btn btn-primary btn-sm font-weight-bold " data-toggle="modal" name="" id="btn_pourc_partie"><i class="fa   fa-file-excel-o"></i> Exporter</button>

</div>
									</h5>
                                    <div class="card-body p-0">
                                         <table class="table table-striped table-bordered table-sm export_pourc_partie" id="bootstrap-data-table-pourc_partie" data-order='[[0,"desc"]]'>
					<thead>
						<tr>
							<th>#</th>
							<th>Partie politique</th>
							<th>Pourcentage</th>
						</tr>
					</thead>
					<tbody>
					<?php 
					$query = "
SELECT partie.id_partie as id_partie,partie.partie as partie, format((SUM(nb_vote) * COUNT(id_vote)/100),2) AS Total FROM vote INNER JOIN partie ON partie.id_partie=vote.id_partie GROUP BY partie.id_partie
		
	";
$statement = $db->prepare($query);
$statement->execute();
$result = $statement->fetchAll();
$total_row = $statement->rowCount();
if($total_row > 0)
{
	foreach($result as $row)
	{
?>
<tr>
<td><?php echo $row["id_partie"]; ?></td>
<td><?php echo $row["partie"] ?></td>
<td><?php echo $row["Total"] ?></td>
</tr>
<?php 
}
}
?>
</tbody>
				</table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- ============================================================== -->
                            <!-- end pourcentage  -->

    
                            <!-- ============================================================== -->
                            <!-- ============================================================== -->
                           
                            <!-- =======================Somme======================================= -->
                        </div>
                        <div class="row">
                            <div class="col-xl-6 col-lg-12 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <h5 class="card-header">
									<div class="col-sm-6">Total des votes par centre

</div>
									<div class="col-sm-2">
			<button class="btn btn-primary btn-sm font-weight-bold " data-toggle="modal" name="" id="btn_somme_centre"><i class="fa   fa-file-excel-o"></i> Exporter</button>

</div>
									</h5>
                                    <div class="card-body p-0">
                                        <div class="table-responsive">
                                           <table class="table table-striped table-bordered table-sm export_somme_centre" id="bootstrap-data-table-somme_centre" data-order='[[0,"desc"]]'>
					<thead>
						<tr>
							<th>#</th>
							<th>Centre de vote</th>
							<th>Total</th>
						</tr>
					</thead>
					<tbody>
					<?php 
					$query = "
SELECT id_vote,centre.nom_centre as nom_centre, format(SUM(nb_vote),2) AS Total FROM vote INNER JOIN bureau ON bureau.id_bureau=vote.id_bureau INNER JOIN centre ON centre.id_centre=bureau.id_centre GROUP BY centre.id_centre
		
	";
$statement = $db->prepare($query);
$statement->execute();
$result = $statement->fetchAll();
$total_row = $statement->rowCount();
if($total_row > 0)
{
	foreach($result as $row)
	{
?>
<tr>
<td><?php echo $row["id_vote"]; ?></td>
<td><?php echo $row["nom_centre"] ?></td>
<td><?php echo $row["Total"] ?></td>
</tr>
<?php 
}
}
?>
</tbody>
				</table>
                                        </div>
                                    </div>
                                </div>
                            </div>
							 <div class="col-xl-6 col-lg-12 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <h5 class="card-header">
									<div class="col-sm-6">Total des votes par partie
</div>
									<div class="col-sm-2">
			<button class="btn btn-primary btn-sm font-weight-bold " data-toggle="modal" name="" id="btn_somme_partie"><i class="fa   fa-file-excel-o"></i> Exporter</button>

</div>
									</h5>
                                    <div class="card-body p-0">
                                        <div class="table-responsive">
                                           <table class="table table-striped table-bordered table-sm export_somme_partie" id="bootstrap-data-table-somme_partie" data-order='[[0,"desc"]]'>
					<thead>
						<tr>
							<th>#</th>
							<th>Partie politique</th>
							<th>Total</th>
						</tr>
					</thead>
					<tbody>
					<?php 
					$query = "
SELECT id_vote,partie.partie as partie, format(SUM(nb_vote) ,2) AS Total FROM vote INNER JOIN partie ON partie.id_partie=vote.id_partie GROUP BY partie.id_partie
	";
$statement = $db->prepare($query);
$statement->execute();
$result = $statement->fetchAll();
$total_row = $statement->rowCount();
if($total_row > 0)
{
	foreach($result as $row)
	{
?>
<tr>
<td><?php echo $row["id_vote"]; ?></td>
<td><?php echo $row["partie"] ?></td>
<td><?php echo $row["Total"] ?></td>
</tr>
<?php 
}
}
?>
</tbody>
				</table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                       
                        <div class="row">
                            <!-- ============================================================== -->
                            <!-- total revenue  -->
                            <!-- ============================================================== -->
  
                            
                            <!-- ============================================================== -->
                            <!-- ============================================================== -->
                            
                            <!-- ============================================================== -->

                       
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
<?php 
include('../include/script.php');
include('../include/footer.php');
?>
<script>
$(document).ready(function () {
    $('#bootstrap-data-table-pourc_centre_somme').DataTable({
            "language": {
                "sEmptyTable":     "Aucune donnée disponible dans le tableau",
                "sInfo":           "Affichage de l'élément _START_ à _END_ sur _TOTAL_ éléments",
                "sInfoEmpty":      "Affichage de l'élément 0 à 0 sur 0 élément",
                "sInfoFiltered":   "(filtré à partir de _MAX_ éléments au total)",
                "sInfoPostFix":    "",
                "sInfoThousands":  ",",
                "sLengthMenu":     "Afficher _MENU_ éléments",
                "sLoadingRecords": "Chargement...",
                "sProcessing":     "Traitement...",
                "sSearch":         "Rechercher :",
                "sZeroRecords":    "Aucun élément correspondant trouvé",
                "oPaginate": {
                    "sFirst":    "Premier",
                    "sLast":     "Dernier",
                    "sNext":     "Suivant",
                    "sPrevious": "Précédent"
                },
                "oAria": {
                    "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
                    "sSortDescending": ": activer pour trier la colonne par ordre décroissant"
                },
                "select": {
                    "rows": {
                        "_": "%d lignes sélectionnées",
                        "0": "Aucune ligne sélectionnée",
                        "1": "1 ligne sélectionnée"
                    }
                }
            }
    });
	$('#bootstrap-data-table-pourc_centre').DataTable({
            "language": {
                "sEmptyTable":     "Aucune donnée disponible dans le tableau",
                "sInfo":           "Affichage de l'élément _START_ à _END_ sur _TOTAL_ éléments",
                "sInfoEmpty":      "Affichage de l'élément 0 à 0 sur 0 élément",
                "sInfoFiltered":   "(filtré à partir de _MAX_ éléments au total)",
                "sInfoPostFix":    "",
                "sInfoThousands":  ",",
                "sLengthMenu":     "Afficher _MENU_ éléments",
                "sLoadingRecords": "Chargement...",
                "sProcessing":     "Traitement...",
                "sSearch":         "Rechercher :",
                "sZeroRecords":    "Aucun élément correspondant trouvé",
                "oPaginate": {
                    "sFirst":    "Premier",
                    "sLast":     "Dernier",
                    "sNext":     "Suivant",
                    "sPrevious": "Précédent"
                },
                "oAria": {
                    "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
                    "sSortDescending": ": activer pour trier la colonne par ordre décroissant"
                },
                "select": {
                    "rows": {
                        "_": "%d lignes sélectionnées",
                        "0": "Aucune ligne sélectionnée",
                        "1": "1 ligne sélectionnée"
                    }
                }
            }
    });
	$('#bootstrap-data-table-pourc_partie').DataTable({
            "language": {
                "sEmptyTable":     "Aucune donnée disponible dans le tableau",
                "sInfo":           "Affichage de l'élément _START_ à _END_ sur _TOTAL_ éléments",
                "sInfoEmpty":      "Affichage de l'élément 0 à 0 sur 0 élément",
                "sInfoFiltered":   "(filtré à partir de _MAX_ éléments au total)",
                "sInfoPostFix":    "",
                "sInfoThousands":  ",",
                "sLengthMenu":     "Afficher _MENU_ éléments",
                "sLoadingRecords": "Chargement...",
                "sProcessing":     "Traitement...",
                "sSearch":         "Rechercher :",
                "sZeroRecords":    "Aucun élément correspondant trouvé",
                "oPaginate": {
                    "sFirst":    "Premier",
                    "sLast":     "Dernier",
                    "sNext":     "Suivant",
                    "sPrevious": "Précédent"
                },
                "oAria": {
                    "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
                    "sSortDescending": ": activer pour trier la colonne par ordre décroissant"
                },
                "select": {
                    "rows": {
                        "_": "%d lignes sélectionnées",
                        "0": "Aucune ligne sélectionnée",
                        "1": "1 ligne sélectionnée"
                    }
                }
            }
    });
		$('#bootstrap-data-table-somme_centre').DataTable({
            "language": {
                "sEmptyTable":     "Aucune donnée disponible dans le tableau",
                "sInfo":           "Affichage de l'élément _START_ à _END_ sur _TOTAL_ éléments",
                "sInfoEmpty":      "Affichage de l'élément 0 à 0 sur 0 élément",
                "sInfoFiltered":   "(filtré à partir de _MAX_ éléments au total)",
                "sInfoPostFix":    "",
                "sInfoThousands":  ",",
                "sLengthMenu":     "Afficher _MENU_ éléments",
                "sLoadingRecords": "Chargement...",
                "sProcessing":     "Traitement...",
                "sSearch":         "Rechercher :",
                "sZeroRecords":    "Aucun élément correspondant trouvé",
                "oPaginate": {
                    "sFirst":    "Premier",
                    "sLast":     "Dernier",
                    "sNext":     "Suivant",
                    "sPrevious": "Précédent"
                },
                "oAria": {
                    "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
                    "sSortDescending": ": activer pour trier la colonne par ordre décroissant"
                },
                "select": {
                    "rows": {
                        "_": "%d lignes sélectionnées",
                        "0": "Aucune ligne sélectionnée",
                        "1": "1 ligne sélectionnée"
                    }
                }
            }
    });
	$('#bootstrap-data-table-somme_partie').DataTable({
            "language": {
                "sEmptyTable":     "Aucune donnée disponible dans le tableau",
                "sInfo":           "Affichage de l'élément _START_ à _END_ sur _TOTAL_ éléments",
                "sInfoEmpty":      "Affichage de l'élément 0 à 0 sur 0 élément",
                "sInfoFiltered":   "(filtré à partir de _MAX_ éléments au total)",
                "sInfoPostFix":    "",
                "sInfoThousands":  ",",
                "sLengthMenu":     "Afficher _MENU_ éléments",
                "sLoadingRecords": "Chargement...",
                "sProcessing":     "Traitement...",
                "sSearch":         "Rechercher :",
                "sZeroRecords":    "Aucun élément correspondant trouvé",
                "oPaginate": {
                    "sFirst":    "Premier",
                    "sLast":     "Dernier",
                    "sNext":     "Suivant",
                    "sPrevious": "Précédent"
                },
                "oAria": {
                    "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
                    "sSortDescending": ": activer pour trier la colonne par ordre décroissant"
                },
                "select": {
                    "rows": {
                        "_": "%d lignes sélectionnées",
                        "0": "Aucune ligne sélectionnée",
                        "1": "1 ligne sélectionnée"
                    }
                }
            }
    });
$('#btn_pourc_centre').click(function(){
	   $ ( ".export_pourc_centre" ) . table2excel ( { 
    exclure : ".pourc_centre" ,
    name : "Worksheet Name" , 
    filename : "pourcentage_centre.xls" ,  // inclure l'extension 
    preserveColors : false  // définir sur true si vous souhaitez que les couleurs d'arrière-plan et les couleurs de police soient préservées 
} ) ;
	   });
	   
	   $('#btn_pourc_partie').click(function(){
	   $ ( ".export_pourc_partie" ) . table2excel ( { 
    exclure : ".pourc_partie" ,
    name : "Worksheet Name" , 
    filename : "pourcentage_partie.xls" ,  // inclure l'extension 
    preserveColors : false  // définir sur true si vous souhaitez que les couleurs d'arrière-plan et les couleurs de police soient préservées 
} ) ;
	   });
	    $('#btn_somme_centre').click(function(){
	   $ ( ".export_somme_centre" ) . table2excel ( { 
    exclure : ".somme_centre" ,
    name : "Worksheet Name" , 
    filename : "total_vote_centre.xls" ,  // inclure l'extension 
    preserveColors : false  // définir sur true si vous souhaitez que les couleurs d'arrière-plan et les couleurs de police soient préservées 
} ) ;
	   });
	    $('#btn_somme_partie').click(function(){
	   $ ( ".export_somme_partie" ) . table2excel ( { 
    exclure : ".somme_partie" ,
    name : "Worksheet Name" , 
    filename : "total_vote_partie.xls" ,  // inclure l'extension 
    preserveColors : false  // définir sur true si vous souhaitez que les couleurs d'arrière-plan et les couleurs de police soient préservées 
} ) ;
	   });
});	
</script>
<?php 
}else if(isset($_SESSION['profil'])==''){
header("Location:../index.php");
}?>