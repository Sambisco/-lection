<!-- left sidebar -->
        <!-- ============================================================== -->
        <div class="nav-left-sidebar sidebar-dark">
            <div class="menu-list">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav flex-column">
                            <li class="nav-divider">
                                Menu
                            </li>
							
                            <li class="nav-item ">
                                <a class="nav-link active" href="../pages/dashboard.php" ><i class="fa fa-fw fa-user-circle"></i>Tableau de bord <span class="badge badge-success">6</span></a>
                                <div id="submenu-1" class="collapse submenu" style="">
                                   
                                </div>
                            </li>
							<?php if($_SESSION['profil']=='Administrateur'){?>
                            <li class="nav-item">
                                <a class="nav-link" href="../pages/centre.php" data-target="#submenu-2" aria-controls="submenu-2"><i class="fa fa-fw fa-rocket"></i>Centre de votes</a>
                                <div id="submenu-2" class="collapse submenu" style="">
                                    
                                </div>
                            </li>
							<?php }else if($_SESSION['profil']=='Utilisateur'){
							}
							?>
							<?php if($_SESSION['profil']=='Administrateur'){?>
                            <li class="nav-item">
                                <a class="nav-link" href="../pages/bureau.php" data-target="#submenu-3" aria-controls="submenu-3"><i class="fas fa-fw fa-chart-pie"></i>Bureau de votes</a>
                                <div id="submenu-3" class="collapse submenu" style="">
                                
                                </div>
                            </li>
							<?php }else if($_SESSION['profil']=='Utilisateur'){
							}
							?>
							<?php if($_SESSION['profil']=='Administrateur'){?>
                            <li class="nav-item ">
                                <a class="nav-link" href="../pages/partie.php"  data-target="#submenu-4" aria-controls="submenu-4"><i class="fab fa-fw fa-wpforms"></i>Parties politiques</a>
                                <div id="submenu-4" class="collapse submenu" style="">
                                   
                                </div>
                            </li>
							<?php }else if($_SESSION['profil']=='Utilisateur'){
							}
							?>
                            <li class="nav-item">
                                <a class="nav-link" href="../pages/inscrit.php"  data-target="#submenu-5" aria-controls="submenu-5"><i class="fas fa-fw fa-table"></i>Inscrits</a>
                                <div id="submenu-5" class="collapse submenu" style="">
                                    
                                </div>
                            </li>
							<li class="nav-item">
                                <a class="nav-link" href="../pages/vote.php"  data-target="#submenu-5" aria-controls="submenu-5"><i class="fas fa-fw fa-file"></i>Votes</a>
                                <div id="submenu-5" class="collapse submenu" style="">
                                    
                                </div>
                            </li>
							<?php if($_SESSION['profil']=='Administrateur'){?>
							<li class="nav-item">
                                <a class="nav-link" href="../pages/utilisateur.php"  data-target="#submenu-5" aria-controls="submenu-5"><i class="fas fa-fw fa-user"></i>Utilisateurs</a>
                                <div id="submenu-5" class="collapse submenu" style="">
                                    
                                </div>
                            </li>
							<?php }else if($_SESSION['profil']=='Utilisateur'){
							}
							?>
							<?php if($_SESSION['profil']=='Administrateur'){?>
                           <li class="nav-item">
                                <a class="nav-link" href="../pages/tableau.php"  data-target="#submenu-5" aria-controls="submenu-5"><i class="fas fa-fw fa-table"></i>Tableau Pourcentage et total</a>
                                <div id="submenu-5" class="collapse submenu" style="">
                                    
                                </div>
                            </li>
							<?php }else if($_SESSION['profil']=='Utilisateur'){
							}
							?>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
		<!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Prêt à quitter?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Sélectionnez "Déconnexion" ci-dessous si vous êtes prêt à mettre fin à votre session en cours.</div>
        <div class="modal-footer">
		 <a class="btn btn-dark" href="../pages/deconnecte.php">Se déconnecter</a>
          <button class="btn btn-outline-danger" type="button" data-dismiss="modal">Annuler</button>
         
        </div>
      </div>
    </div>
  </div>
        <!-- ============================================================== -->
        <!-- end left sidebar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- wrapper  -->