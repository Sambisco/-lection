<?php
try{
$db=new PDO('mysql:host=localhost;dbname=election',"root","");
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
 $db->exec('SET NAMES utf8 COLLATE utf8_unicode_ci');
 }catch(PDOEXCEPTION $e){
 echo "Erreur".$e->getMessage();
 exit();
 }
 ?>