<?php include('../include/database.php');?>
<?php 
session_start();
 if(isset($_POST['insertdata'])){
 $nom_centre=$_POST['nom_centre'];
 $lieu=$_POST['lieu'];
 $query="INSERT INTO centre(nom_centre,lieu)VALUES(?,?)";
 $statement=$db->prepare($query);
$statement->execute(array($nom_centre,$lieu));
 $_SESSION['message_add']="Les données ont été enregistrées";
 $_SESSION['msg_type_add']="success";
header("location:../pages/centre.php");
} 

if(isset($_POST['updatetdata'])){
  $id=$_POST['id_centre'];
 $nom_centre=$_POST['nom_centre'];
 $lieu=$_POST['lieu'];
 $query="UPDATE centre SET nom_centre= '$nom_centre',lieu=' $lieu' WHERE id_centre='$id'";
 $statement=$db->prepare($query);
$statement->execute(array($nom_centre,$lieu));
 $_SESSION['message_update']="Les modifications ont été effectuées ";
 $_SESSION['msg_type_update']="warning";
header("location:../pages/centre.php");
}

if(isset($_POST['deletedata'])){
  $id=$_POST['delete_id'];

 $query="DELETE FROM centre WHERE id_centre='$id'";
 $statement=$db->prepare($query);
$statement->execute(array($id));
 $_SESSION['message_delete']="Suppression effectuée avec succés";
 $_SESSION['msg_type_delete']="danger";
header("location:../pages/centre.php");
}
?>