<?php include('../include/database.php');?>
<?php 
session_start();
 if(isset($_POST['insertdata'])){
 $id_bureau=$_POST['id_bureau'];
 $id_partie=$_POST['id_partie'];
  $nb_vote=$_POST['nb_vote'];
 $query="INSERT INTO vote(id_bureau,id_partie,nb_vote)VALUES(?,?,?)";
 $statement=$db->prepare($query);
$statement->execute(array($id_bureau,$id_partie,$nb_vote));
 $_SESSION['message_add']="Les données ont été enregistrées";
 $_SESSION['msg_type_add']="success";
header("location:../pages/vote.php");
} 

if(isset($_POST['updatetdata'])){
  $id=$_POST['id_vote'];
 $id_bureau=$_POST['id_bureau'];
 $id_partie=$_POST['id_partie'];
  $nb_vote=$_POST['nb_vote'];
 $query="UPDATE vote SET id_bureau= '$id_bureau',id_partie='$id_partie',nb_vote=' $nb_vote' WHERE id_vote='$id'";
 $statement=$db->prepare($query);
$statement->execute(array($id_bureau,$id_partie,$nb_vote));
 $_SESSION['message_update']="Les modifications ont été effectuées ";
 $_SESSION['msg_type_update']="warning";
header("location:../pages/vote.php");
}

if(isset($_POST['deletedata'])){
  $id=$_POST['delete_id'];

 $query="DELETE FROM vote WHERE id_vote='$id'";
 $statement=$db->prepare($query);
$statement->execute(array($id));
 $_SESSION['message_delete']="Suppression effectuée avec succés";
 $_SESSION['msg_type_delete']="danger";
header("location:../pages/vote.php");
}
?>