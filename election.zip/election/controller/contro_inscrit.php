<?php include('../include/database.php');?>
<?php 
session_start();
 if(isset($_POST['insertdata'])){
 $id_bureau=$_POST['id_bureau'];
 $nb_inscrit=$_POST['nb_inscrit'];
 $query="INSERT INTO inscrit(id_bureau,nb_inscrit)VALUES(?,?)";
 $statement=$db->prepare($query);
$statement->execute(array($id_bureau,$nb_inscrit));
 $_SESSION['message_add']="Les données ont été enregistrées";
 $_SESSION['msg_type_add']="success";
header("location:../pages/inscrit.php");
} 

if(isset($_POST['updatetdata'])){
  $id=$_POST['id_inscrit'];
 $id_bureau=$_POST['id_bureau'];
 $nb_inscrit=$_POST['nb_inscrit'];
 $query="UPDATE inscrit SET id_bureau= '$id_bureau',nb_inscrit=' $nb_inscrit' WHERE id_inscrit='$id'";
 $statement=$db->prepare($query);
$statement->execute(array($id_bureau,$nb_inscrit));
 $_SESSION['message_update']="Les modifications ont été effectuées ";
 $_SESSION['msg_type_update']="warning";
header("location:../pages/inscrit.php");
}

if(isset($_POST['deletedata'])){
  $id=$_POST['delete_id'];

 $query="DELETE FROM inscrit WHERE id_inscrit='$id'";
 $statement=$db->prepare($query);
$statement->execute(array($id));
 $_SESSION['message_delete']="Suppression effectuée avec succés";
 $_SESSION['msg_type_delete']="danger";
header("location:../pages/inscrit.php");
}
?>