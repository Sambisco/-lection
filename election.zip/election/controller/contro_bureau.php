<?php include('../include/database.php');?>
<?php 
session_start();
 if(isset($_POST['insertdata'])){
 $nom_bureau=$_POST['nom_bureau'];
 $id_centre=$_POST['id_centre'];
 $query="INSERT INTO bureau(nom_bureau,id_centre)VALUES(?,?)";
 $statement=$db->prepare($query);
$statement->execute(array($nom_bureau,$id_centre));
 $_SESSION['message_add']="Les données ont été enregistrées";
 $_SESSION['msg_type_add']="success";
header("location:../pages/bureau.php");
} 

if(isset($_POST['updatetdata'])){
  $id=$_POST['id_bureau'];
 $nom_bureau=$_POST['nom_bureau'];
 $id_centre=$_POST['id_centre'];
 $query="UPDATE bureau SET nom_bureau= '$nom_bureau',id_centre=' $id_centre' WHERE id_bureau='$id'";
 $statement=$db->prepare($query);
$statement->execute(array($nom_centre,$lieu));
 $_SESSION['message_update']="Les modifications ont été effectuées ";
 $_SESSION['msg_type_update']="warning";
header("location:../pages/bureau.php");
}

if(isset($_POST['deletedata'])){
  $id=$_POST['delete_id'];

 $query="DELETE FROM bureau WHERE id_bureau='$id'";
 $statement=$db->prepare($query);
$statement->execute(array($id));
 $_SESSION['message_delete']="Suppression effectuée avec succés";
 $_SESSION['msg_type_delete']="danger";
header("location:../pages/bureau.php");
}
?>