<?php
if(!isset($_SESSION['id_utilisateur']) AND isset($_COOKIE['email'],$_COOKIE['password']) AND !empty($_COOKIE['email']) AND !empty($_COOKIE['password'])) {
   $requser = $db->prepare("SELECT * FROM utilisateur INNER JOIN centre ON                                    centre.id_centre=utilisateur.id_centre  WHERE login = ? AND password = ?");
   $requser->execute(array($_COOKIE['email'], $_COOKIE['password']));
   $userexist = $requser->rowCount();
   if($userexist == 1)
   {
      $userinfo = $requser->fetch();
      $_SESSION['id_utilisateur'] = $userinfo['id_utilisateur'];
      $_SESSION['nom']= $userinfo['nom'];
$_SESSION['profil']= $userinfo['profil'];
$_SESSION['id_centre']= $userinfo['id_centre'];
   }
}
?>