<?php

//data.php

include('../include/database.php');

if(isset($_POST["action"]))
{
	if($_POST["action"] == 'insert')
	{
		$data = array(
			':language'		=>	$_POST["language"]
		);

		$query = "
		INSERT INTO vote 
		(nb_vote) VALUES (:nb_vote)
		";

		$statement = $db->prepare($query);

		$statement->execute($data);

		echo 'done';
	}

	if($_POST["action"] == 'fetch')
	{
		$query = "
		SELECT centre.nom_centre as nom_centre, format(SUM(nb_vote),2) AS Total FROM vote INNER JOIN bureau ON bureau.id_bureau=vote.id_bureau INNER JOIN centre ON centre.id_centre=bureau.id_centre GROUP BY centre.id_centre
		";

		$result = $db->query($query);

		$data = array();

		foreach($result as $row)
		{
			$data[] = array(
				'language'		=>	$row["nom_centre"],
				'total'			=>	$row["Total"],
				'color'			=>	'#' . rand(100000, 999999) . ''
			);
		}

		echo json_encode($data);
	}
}


?>