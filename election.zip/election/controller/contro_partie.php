<?php include('../include/database.php');?>
<?php 
session_start();
 if(isset($_POST['insertdata'])){
 $partie=$_POST['partie'];
 $query="INSERT INTO partie(partie)VALUES(?)";
 $statement=$db->prepare($query);
$statement->execute(array($partie));
 $_SESSION['message_add']="Les données ont été enregistrées";
 $_SESSION['msg_type_add']="success";
header("location:../pages/partie.php");
} 

if(isset($_POST['updatetdata'])){
  $id=$_POST['id_partie'];
 $partie=$_POST['partie'];
 $query="UPDATE partie SET partie= '$partie' WHERE id_partie='$id'";
 $statement=$db->prepare($query);
$statement->execute(array($partie));
 $_SESSION['message_update']="Les modifications ont été effectuées ";
 $_SESSION['msg_type_update']="warning";
header("location:../pages/partie.php");
}

if(isset($_POST['deletedata'])){
  $id=$_POST['delete_id'];

 $query="DELETE FROM partie WHERE id_partie='$id'";
 $statement=$db->prepare($query);
$statement->execute(array($id));
 $_SESSION['message_delete']="Suppression effectuée avec succés";
 $_SESSION['msg_type_delete']="danger";
header("location:../pages/partie.php");
}
?>