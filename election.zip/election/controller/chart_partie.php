<?php

//data.php

include('../include/database.php');

if(isset($_POST["action"]))
{
	if($_POST["action"] == 'insert')
	{
		$data = array(
			':language'		=>	$_POST["language"]
		);

		$query = "
		INSERT INTO vote 
		(nb_vote) VALUES (:nb_vote)
		";

		$statement = $db->prepare($query);

		$statement->execute($data);

		echo 'done';
	}

	if($_POST["action"] == 'fetch')
	{
		$query = "
		SELECT partie.partie as partie, format((SUM(nb_vote) * COUNT(id_vote)/100),2) AS Total FROM vote INNER JOIN partie ON partie.id_partie=vote.id_partie GROUP BY partie.id_partie
		";

		$result = $db->query($query);

		$data = array();

		foreach($result as $row)
		{
			$data[] = array(
				'language'		=>	$row["partie"],
				'total'			=>	$row["Total"],
				'color'			=>	'#' . rand(100000, 999999) . ''
			);
		}

		echo json_encode($data);
	}
}


?>