
          <!-- Topbar Search -->
<?php include('../include/database.php');?>
<?php 
session_start();
 if(isset($_POST['insertdata'])){
  $login = $_POST["login"];
   $query="SELECT login FROM utilisateur WHERE login='$login'";
     $statement=$db->prepare($query);
	$statement->execute();
$result=$statement->fetchAll();
$total_row=$statement->rowCount();
    if ($total_row>0){
	$_SESSION['message_delete']="L'identifiant existe déja. Veillez créér un nouveau identifiant!";
 $_SESSION['msg_type_delete']="danger";
  header("location:../pages/utilisateur.php");
	}else{
 $nom=$_POST['nom'];
 $login=$_POST['login'];
 $password=md5($_POST['password']);
 $profil=$_POST['profil'];
 $id_centre=$_POST['id_centre'];
 $query="INSERT INTO `utilisateur`( `nom`, `login`, `password`, `profil`, `id_centre`) VALUES(?,?,?,?,?)";
 $statement=$db->prepare($query);
$statement->execute(array($nom,$login,$password,$profil,$id_centre));
 $_SESSION['message_add']="Les données ont été enregistrées";
 $_SESSION['msg_type_add']="success";
header("location:../pages/utilisateur.php");
} 
 }
 if(isset($_POST['updatetdata'])){
  $profil=$_POST['profil'];
$id_centre=$_POST['id_centre'];
 $password=md5($_POST['password']);
$newpassword=md5($_POST['newpassword']);
$login=$_POST['login'];
$con="update utilisateur set password=:newpassword,profil=:profil,id_centre=:id_centre where login=:login";
$chngpwd1 = $db->prepare($con);
$chngpwd1-> bindParam(':profil', $profil, PDO::PARAM_STR);
$chngpwd1-> bindParam(':id_centre', $id_etablissement, PDO::PARAM_STR);
$chngpwd1-> bindParam(':login', $email, PDO::PARAM_STR);
$chngpwd1-> bindParam(':newpassword', $newpassword, PDO::PARAM_STR);
$chngpwd1->execute();
  $_SESSION['message_update']="Le mot de passe a été modifier ";
 $_SESSION['msg_type_update']="warning";
header("location:../pages/utilisateur.php");
    }
 
 if(isset($_POST['deletedata'])){
  $id=$_POST['delete_id'];


 $query="DELETE FROM utilisateur WHERE id_utilisateur=$id";
 $statement=$db->prepare($query);
$statement->execute(array( $id));
 $_SESSION['message_delete']="Suppression effectuée avec succés";
 $_SESSION['msg_type_delete']="danger";
header("location:../pages/utilisateur.php");
}
 ?>